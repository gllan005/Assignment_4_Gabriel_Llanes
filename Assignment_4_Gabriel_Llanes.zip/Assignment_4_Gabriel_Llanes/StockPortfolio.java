/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stock.portfolio;

/**
 *I affirm that this program is entirely my own work and none 
 * of it is the work of any other person.
 * @author Gabriel Llanes
 * Instructor: Caryl Rahn
 * COP 2210 U02 Thursday 11:00 a.m. lab
 */
public class StockPortfolio {
//Initialize variables in constructor 
    private String companyName;
    private int sharesHeld, dollarSharePrice, eithsSharePrice;
    public StockPortfolio(String companyName, int sharesHeld,
            int dollarSharePrice, int eithsSharePrice){
    this.companyName = companyName;
    this.dollarSharePrice = dollarSharePrice;
    this.eithsSharePrice = eithsSharePrice;
    this.sharesHeld = sharesHeld; 
    }
    // Use accessor(get method) and mutator(set method)
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public int getSharesHeld() {
        return sharesHeld;
    }

    public void setSharesHeld(int sharesHeld) {
        this.sharesHeld = sharesHeld;
    }
    public int getDollarSharePrice() {
        return dollarSharePrice;
    }

    public void setDollarSharePrice(int dollarSharePrice) {
        this.dollarSharePrice = dollarSharePrice;
    }
    public int getEithsSharePrice() {
        return eithsSharePrice;
    }

    public void setEithsSharePrice(int eithsSharePrice) {
        this.eithsSharePrice = eithsSharePrice;
    }
    public void modifyStockPrice(int changeDollar, int changeEith){
    dollarSharePrice += changeDollar;
    eithsSharePrice += changeEith;
    dollarSharePrice += eithsSharePrice/8;
    eithsSharePrice = eithsSharePrice%8;
    }
    
    public double portfolioValue(){
    double portfolioValue;
    portfolioValue = sharesHeld*(dollarSharePrice + eithsSharePrice/8.0);
    return portfolioValue;
    }
}
